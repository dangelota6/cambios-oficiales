function mostrar(id) {
    
	if (id == "tabla_2018") {
		$("#tabla_2018").show();
		$("#tabla_2017").hide();
		$("#tabla_2016").hide();
		$("#tabla_2015").hide();
		$("#tabla_2014").hide();
		$("#tabla_2013").hide();
		$("#tabla_2012").hide();
		$("#tabla_2011").hide();
		$("#tabla_2010").hide();
		$("#tabla_2009").hide();
		$("#tabla_2008").hide();
		$("#tabla_2007").hide();
		$("#tabla_2006").hide();
		$("#tabla_2005").hide();
		$("#tabla_2004").hide();
		$("#tabla_2003").hide();
	}

	
	if (id == "tabla_2017") {
		$("#tabla_2018").hide();
		$("#tabla_2017").show();
		$("#tabla_2016").hide();
		$("#tabla_2015").hide();
		$("#tabla_2014").hide();
		$("#tabla_2013").hide();
		$("#tabla_2012").hide();
		$("#tabla_2011").hide();
		$("#tabla_2010").hide();
		$("#tabla_2009").hide();
		$("#tabla_2008").hide();
		$("#tabla_2007").hide();
		$("#tabla_2006").hide();
		$("#tabla_2005").hide();
		$("#tabla_2004").hide();
		$("#tabla_2003").hide();
	}

	if (id == "tabla_2016") {
		$("#tabla_2018").hide();
		$("#tabla_2017").hide();
		$("#tabla_2016").show();
		$("#tabla_2015").hide();
		$("#tabla_2014").hide();
		$("#tabla_2013").hide();
		$("#tabla_2012").hide();
		$("#tabla_2011").hide();
		$("#tabla_2010").hide();
		$("#tabla_2009").hide();
		$("#tabla_2008").hide();
		$("#tabla_2007").hide();
		$("#tabla_2006").hide();
		$("#tabla_2005").hide();
		$("#tabla_2004").hide();
		$("#tabla_2003").hide();
	}

	if (id == "tabla_2015") {
		$("#tabla_2018").hide();
		$("#tabla_2017").hide();
		$("#tabla_2016").hide();
		$("#tabla_2015").show();
		$("#tabla_2014").hide();
		$("#tabla_2013").hide();
		$("#tabla_2012").hide();
		$("#tabla_2011").hide();
		$("#tabla_2010").hide();
		$("#tabla_2009").hide();
		$("#tabla_2008").hide();
		$("#tabla_2007").hide();
		$("#tabla_2006").hide();
		$("#tabla_2005").hide();
		$("#tabla_2004").hide();
		$("#tabla_2003").hide();
	}

	if (id == "tabla_2014") {
		$("#tabla_2018").hide();
		$("#tabla_2017").hide();
		$("#tabla_2016").hide();
		$("#tabla_2015").hide();
		$("#tabla_2014").show();
		$("#tabla_2013").hide();
		$("#tabla_2012").hide();
		$("#tabla_2011").hide();
		$("#tabla_2010").hide();
		$("#tabla_2009").hide();
		$("#tabla_2008").hide();
		$("#tabla_2007").hide();
		$("#tabla_2006").hide();
		$("#tabla_2005").hide();
		$("#tabla_2004").hide();
		$("#tabla_2003").hide();
	}

	
	if (id == "tabla_2013") {
		$("#tabla_2018").hide();
		$("#tabla_2017").hide();
		$("#tabla_2016").hide();
		$("#tabla_2015").hide();
		$("#tabla_2014").hide();
		$("#tabla_2013").show();
		$("#tabla_2012").hide();
		$("#tabla_2011").hide();
		$("#tabla_2010").hide();
		$("#tabla_2009").hide();
		$("#tabla_2008").hide();
		$("#tabla_2007").hide();
		$("#tabla_2006").hide();
		$("#tabla_2005").hide();
		$("#tabla_2004").hide();
		$("#tabla_2003").hide();
	}

	if (id == "tabla_2012") {
		$("#tabla_2018").hide();
		$("#tabla_2017").hide();
		$("#tabla_2016").hide();
		$("#tabla_2015").hide();
		$("#tabla_2014").hide();
		$("#tabla_2013").hide();
		$("#tabla_2012").show();
		$("#tabla_2011").hide();
		$("#tabla_2010").hide();
		$("#tabla_2009").hide();
		$("#tabla_2008").hide();
		$("#tabla_2007").hide();
		$("#tabla_2006").hide();
		$("#tabla_2005").hide();
		$("#tabla_2004").hide();
		$("#tabla_2003").hide();
	}

	if (id == "tabla_2011") {
		$("#tabla_2018").hide();
		$("#tabla_2017").hide();
		$("#tabla_2016").hide();
		$("#tabla_2015").hide();
		$("#tabla_2014").hide();
		$("#tabla_2013").hide();
		$("#tabla_2012").hide();
		$("#tabla_2011").show();
		$("#tabla_2010").hide();
		$("#tabla_2009").hide();
		$("#tabla_2008").hide();
		$("#tabla_2007").hide();
		$("#tabla_2006").hide();
		$("#tabla_2005").hide();
		$("#tabla_2004").hide();
		$("#tabla_2003").hide();
	}

	if (id == "tabla_2010") {
		$("#tabla_2018").hide();
		$("#tabla_2017").hide();
		$("#tabla_2016").hide();
		$("#tabla_2015").hide();
		$("#tabla_2014").hide();
		$("#tabla_2013").hide();
		$("#tabla_2012").hide();
		$("#tabla_2011").hide();
		$("#tabla_2010").show();
		$("#tabla_2009").hide();
		$("#tabla_2008").hide();
		$("#tabla_2007").hide();
		$("#tabla_2006").hide();
		$("#tabla_2005").hide();
		$("#tabla_2004").hide();
		$("#tabla_2003").hide();
	}

	if (id == "tabla_2009") {
		$("#tabla_2018").hide();
		$("#tabla_2017").hide();
		$("#tabla_2016").hide();
		$("#tabla_2015").hide();
		$("#tabla_2014").hide();
		$("#tabla_2013").hide();
		$("#tabla_2012").hide();
		$("#tabla_2011").hide();
		$("#tabla_2010").hide();
		$("#tabla_2009").show();
		$("#tabla_2008").hide();
		$("#tabla_2007").hide();
		$("#tabla_2006").hide();
		$("#tabla_2005").hide();
		$("#tabla_2004").hide();
		$("#tabla_2003").hide();
	}

	if (id == "tabla_2008") {
		$("#tabla_2018").hide();
		$("#tabla_2017").hide();
		$("#tabla_2016").hide();
		$("#tabla_2015").hide();
		$("#tabla_2014").hide();
		$("#tabla_2013").hide();
		$("#tabla_2012").hide();
		$("#tabla_2011").hide();
		$("#tabla_2010").hide();
		$("#tabla_2009").hide();
		$("#tabla_2008").show();
		$("#tabla_2007").hide();
		$("#tabla_2006").hide();
		$("#tabla_2005").hide();
		$("#tabla_2004").hide();
		$("#tabla_2003").hide();
	}

	if (id == "tabla_2007") {
		$("#tabla_2018").hide();
		$("#tabla_2017").hide();
		$("#tabla_2016").hide();
		$("#tabla_2015").hide();
		$("#tabla_2014").hide();
		$("#tabla_2013").hide();
		$("#tabla_2012").hide();
		$("#tabla_2011").hide();
		$("#tabla_2010").hide();
		$("#tabla_2009").hide();
		$("#tabla_2008").hide();
		$("#tabla_2007").show();
		$("#tabla_2006").hide();
		$("#tabla_2005").hide();
		$("#tabla_2004").hide();
		$("#tabla_2003").hide();
	}

	
	if (id == "tabla_2006") {
		$("#tabla_2018").hide();
		$("#tabla_2017").hide();
		$("#tabla_2016").hide();
		$("#tabla_2015").hide();
		$("#tabla_2014").hide();
		$("#tabla_2013").hide();
		$("#tabla_2012").hide();
		$("#tabla_2011").hide();
		$("#tabla_2010").hide();
		$("#tabla_2009").hide();
		$("#tabla_2008").hide();
		$("#tabla_2007").hide();
		$("#tabla_2006").show();
		$("#tabla_2005").hide();
		$("#tabla_2004").hide();
		$("#tabla_2003").hide();
	}


	if (id == "tabla_2005") {
		$("#tabla_2018").hide();
		$("#tabla_2017").hide();
		$("#tabla_2016").hide();
		$("#tabla_2015").hide();
		$("#tabla_2014").hide();
		$("#tabla_2013").hide();
		$("#tabla_2012").hide();
		$("#tabla_2011").hide();
		$("#tabla_2010").hide();
		$("#tabla_2009").hide();
		$("#tabla_2008").hide();
		$("#tabla_2007").hide();
		$("#tabla_2006").hide();
		$("#tabla_2005").show();
		$("#tabla_2004").hide();
		$("#tabla_2003").hide();
	}

	if (id == "tabla_2004") {
		$("#tabla_2018").hide();
		$("#tabla_2017").hide();
		$("#tabla_2016").hide();
		$("#tabla_2015").hide();
		$("#tabla_2014").hide();
		$("#tabla_2013").hide();
		$("#tabla_2012").hide();
		$("#tabla_2011").hide();
		$("#tabla_2010").hide();
		$("#tabla_2009").hide();
		$("#tabla_2008").hide();
		$("#tabla_2007").hide();
		$("#tabla_2006").hide();
		$("#tabla_2005").hide();
		$("#tabla_2004").show();
		$("#tabla_2003").hide();
	}

	if (id == "tabla_2003") {
		$("#tabla_2018").hide();
		$("#tabla_2017").hide();
		$("#tabla_2016").hide();
		$("#tabla_2015").hide();
		$("#tabla_2014").hide();
		$("#tabla_2013").hide();
		$("#tabla_2012").hide();
		$("#tabla_2011").hide();
		$("#tabla_2010").hide();
		$("#tabla_2009").hide();
		$("#tabla_2008").hide();
		$("#tabla_2007").hide();
		$("#tabla_2006").hide();
		$("#tabla_2005").hide();
		$("#tabla_2004").hide();
		$("#tabla_2003").show();
	}


	}